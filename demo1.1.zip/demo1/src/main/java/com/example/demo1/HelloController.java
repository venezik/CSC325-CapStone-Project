package com.example.demo1;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;

/**
 * Controller class for the main application view.
 */
public class HelloController {

    @FXML
    private BorderPane borderPane;


    @FXML
    private CheckBox checkBox1;
    @FXML
    private CheckBox checkBox2;
    @FXML
    private CheckBox checkBox3;
    @FXML
    private CheckBox checkBox4;
    @FXML
    private CheckBox checkBox5;
    @FXML
    private CheckBox checkBox6;
    @FXML
    private CheckBox checkBox7;
    @FXML
    private CheckBox checkBox8;
    @FXML
    private CheckBox checkBox9;
    @FXML
    private CheckBox checkBox10;
    @FXML
    private CheckBox checkBox11;
    @FXML
    private CheckBox checkBox12;

    @FXML
    private Button logInPage;

    @FXML
    protected void initialize() {
        // Initialization code
    }

    /**
     * Switches to the login page.
     */
    @FXML
    private void setLogInPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("loginPage.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) logInPage.getScene().getWindow();
            Scene scene = new Scene(root, 1200, 750);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }

    /**
     * Handles the selection/deselection of price filter 1.
     */
    @FXML
    private void priceFilter1() {
        if (checkBox1.isSelected()) {
            filter1open();
        } else {
            filter1switch();
        }
    }

    /**
     * Handles the selection/deselection of price filter 2.
     */
    @FXML
    private void priceFilter2() {
        if (checkBox2.isSelected()) {
            filter2open();
        } else {
            filter1switch();
        }
    }

    /**
     * Handles the selection/deselection of price filter 3.
     */
    @FXML
    private void priceFilter3() {
        if (checkBox3.isSelected()) {
            filter3open();
        } else {
            filter1switch();
        }
    }

     /**
     * Handles the selection/deselection of price filter 4.
     */
    @FXML
    private void priceFilter4() {
        if (checkBox4.isSelected()) {
            filter4open();
        } else {
            filter1switch();
        }
    }

      /**
     * Handles the selection/deselection of price filter 5.
     */
    @FXML
    private void priceFilter5() {
        if (checkBox5.isSelected()) {
            filter5open();
        } else {
            filter1switch();
        }
    }  
    
    /**
    * Handles the selection/deselection of price filter 6.
    */
   @FXML
   private void priceFilter6() {
       if (checkBox6.isSelected()) {
           filter4open();
       } else {
           filter1switch();
       }
   }  
   
   /**
   * Handles the selection/deselection of price filter 7.
   */
  @FXML
  private void priceFilter7() {
      if (checkBox7.isSelected()) {
          filter7open();
      } else {
          filter1switch();
      }
  }  
  
  /**
  * Handles the selection/deselection of price filter 8.
  */
 @FXML
 private void priceFilter8() {
     if (checkBox8.isSelected()) {
         filter8open();
     } else {
         filter1switch();
     }
 }  
 
 /**
 * Handles the selection/deselection of price filter 9.
 */
@FXML
private void priceFilter9() {
    if (checkBox9.isSelected()) {
        filter9open();
    } else {
        filter1switch();
    }
}  

/**
* Handles the selection/deselection of price filter 10.
*/
@FXML
private void priceFilter10() {
   if (checkBox10.isSelected()) {
       filter10open();
   } else {
       filter1switch();
   }
}  

/**
* Handles the selection/deselection of price filter 11.
*/
@FXML
private void priceFilter11() {
   if (checkBox11.isSelected()) {
       filter11open();
   } else {
       filter1switch();
   }
}  

/**
* Handles the selection/deselection of price filter 12.
*/
@FXML
private void priceFilter12() {
   if (checkBox12.isSelected()) {
       filter12open();
   } else {
       filter1switch();
   }
}  

    /**
     * Opens filter 1.
     */
    public void filter1open() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("filter1.fxml"));
            Pane centerPane = loader.load();
            borderPane.setCenter(centerPane);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }

    /**
     * Opens filter 2.
     */
    public void filter2open() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("filter2.fxml"));
            Pane centerPane = loader.load();
            borderPane.setCenter(centerPane);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }

    /**
     * Opens filter 3.
     */
    public void filter3open() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("filter3.fxml"));
            Pane centerPane = loader.load();
            borderPane.setCenter(centerPane);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }

    /**
     * Opens filter 4.
     */
    public void filter4open() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("filter4.fxml"));
            Pane centerPane = loader.load();
            borderPane.setCenter(centerPane);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }

    /**
     * Opens filter 5.
     */
    public void filter5open() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("filter5.fxml"));
            Pane centerPane = loader.load();
            borderPane.setCenter(centerPane);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }
    
    /**
     * Opens filter 7.
     */
    public void filter7open() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("filter7.fxml"));
            Pane centerPane = loader.load();
            borderPane.setCenter(centerPane);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }
    /**
     * Opens filter 8.
     */
    public void filter8open() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("filter8.fxml"));
            Pane centerPane = loader.load();
            borderPane.setCenter(centerPane);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }
    /**
     * Opens filter 9.
     */
    public void filter9open() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("filter9.fxml"));
            Pane centerPane = loader.load();
            borderPane.setCenter(centerPane);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }
    /**
     * Opens filter 10.
     */
    public void filter10open() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("filter10.fxml"));
            Pane centerPane = loader.load();
            borderPane.setCenter(centerPane);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }
    /**
     * Opens filter 11.
     */
    public void filter11open() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("filter11.fxml"));
            Pane centerPane = loader.load();
            borderPane.setCenter(centerPane);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }
    /**
     * Opens filter 12.
     */
    public void filter12open() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("filter12.fxml"));
            Pane centerPane = loader.load();
            borderPane.setCenter(centerPane);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }
   
    /**
     * Switches to the main page.
     */
    public void filter1switch() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("mainpage.fxml"));
            Pane centerPane = loader.load();
            borderPane.setCenter(centerPane);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }

    /**
     * Opens a pop-up window.
     *
     * @param fxmlFile The FXML file to load.
     */
    private void openPopUp(String fxmlFile) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage popupStage = new Stage();
            popupStage.initStyle(StageStyle.UNDECORATED);
            popupStage.initModality(Modality.APPLICATION_MODAL);
            popupStage.setScene(scene);
            Pane overlayPane = new Pane();
            overlayPane.setStyle("-fx-background-color: rgba(0, 0, 0, 0.5)");
            overlayPane.setPrefSize(popupStage.getWidth(), popupStage.getHeight());
            root.setOnMouseClicked(event -> event.consume());
            ((Pane) root).getChildren().add(overlayPane);
            popupStage.show();
            popupStage.toFront();
            Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
            double centerX = screenBounds.getMinX() + (screenBounds.getWidth() - popupStage.getWidth()) / 2;
            double centerY = screenBounds.getMinY() + (screenBounds.getHeight() - popupStage.getHeight()) / 2;
            popupStage.setX(centerX);
            popupStage.setY(centerY);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
    }

    // Methods to open various pop-ups
    @FXML
    private void openIphonePopup() {
        openPopUp("iphonepopup.fxml");
    }

    @FXML
    private void openPsPopup() {
        openPopUp("ps5popup.fxml");
    }

    @FXML
    private void openSonyHeadphonePopUp() {
        openPopUp("sonyHeadphones.fxml");
    }

    @FXML
    private void openXboxXPopUp() {
        openPopUp("xboxx.fxml");
    }

    @FXML
    private void openSurfacePopup() {
        openPopUp("surfaclaptop.fxml");
    }

    @FXML
    private void openPixelPopUp() {
        openPopUp("googlepixel.fxml");
    }

    @FXML
    private void openBudsPopUp() {
        openPopUp("googlebuds.fxml");
    }

    @FXML
    private void openAirpodsPopUp() {
        openPopUp("airpods.fxml");
    }

    @FXML
    private void openPixelbookPopUp() {
        openPopUp("pixelbook.fxml");
    }

    @FXML
    private void openMacbookPopUp() {
        openPopUp("macbook.fxml");
    }

    @FXML
    private void openXperiaPopUp() {
        openPopUp("xperia.fxml");
    }

    @FXML
    private void openXboxSPopUp() {
        openPopUp("xboxs.fxml");
    }
}
