package com.example.demo1;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class Filter1 {
    @FXML
    private Button button;


}
